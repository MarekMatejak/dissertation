At least two possible options for Modelica environments: Dymola and OpenModelica. 
However, the last version of Physiomodel is developed mainly in Dymola environment.

1. Dymola environment (better, commercial Modelica environment)

 - register and download http://www.3ds.com/products-services/catia/products/dymola/trial-version/

 - install

 - open Dymola

 - copy the CD to a working folder (models needs write permissions for generating results)

 - open "Physiolibrary 2.3.0/package.mo"

 - first setting of the compiler (needed for simulation): press "Ctrl+F2" > menu: Simulation > Setup > Compiler  

  Example of navigation in Dymola application:
     - load model: press "Ctrl+O" find file "working folder/Physiomodel/package.mo"
     - open model diagram: left side of application - Package browser > Physiomodel > Physiomodel_Main - double click
     - simulation: right bottom - "Simulation" > menu: Simulation > Simulate  
     - back to modeling mode: right bottom - "Modeling" or press "Ctrl+F1"



2. OpenModelica environment (free, noncommercial):

 - download https://build.openmodelica.org/omc/builds/windows/releases/1.9.2/OpenModelica-1.9.2-revision-25117.exe
 
 - install 

 - open OMEdit (OpenModelica Connection Editor)
 
 - Physiolibrary is already included in some OpenModelica distributions: 
   menu: File > System Libraries > Physiolibrary

  Example of the navigation

	- Left side of applicatio: Libraries browser > Physiolibrary > Chemical > Examples > SimpleReaction (double click)
	- Press "Ctrl+B" for simulation
	- Right side of application: Variable browser > A > solute; B > solute
	- Right bottom corner to switch back to modeling mode: "Modeling" 

