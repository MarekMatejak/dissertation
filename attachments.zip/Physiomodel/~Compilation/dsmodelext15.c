#include <moutil.c>
PreNonAliasDef(16)
StartNonAlias(15)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[15].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[15].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[15].Nominal",\
 "", 1.0399767045218187E-012, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[15].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[16].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", \
6.239860227130914E-014, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[16].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[16].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[16].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[16].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[16].Nominal",\
 "", 6.239860227130914E-014, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[16].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[17].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", \
6.239860227130913E-011, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[17].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[17].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[17].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[17].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[17].Nominal",\
 "", 6.239860227130913E-011, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[17].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[18].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", \
6.239860227130914E-010, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[18].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[18].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[18].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[18].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[18].Nominal",\
 "", 6.239860227130914E-010, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[18].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[19].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", \
6.239860227130914E-008, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[19].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[19].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[19].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[19].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[19].Nominal",\
 "", 6.239860227130914E-008, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[19].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[20].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", \
1.039976704521819E-015, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[20].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[20].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[20].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[20].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[20].Nominal",\
 "", 1.039976704521819E-015, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[20].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[21].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", \
6.239860227130913E-017, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[21].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[21].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[21].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[21].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[21].Nominal",\
 "", 6.239860227130913E-017, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[21].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[22].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", \
6.239860227130914E-014, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[22].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[22].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[22].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[22].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[22].Nominal",\
 "", 6.239860227130914E-014, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[22].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[23].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", \
6.239860227130914E-013, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[23].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[23].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[23].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[23].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[23].Nominal",\
 "", 6.239860227130914E-013, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[23].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[24].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", \
6.239860227130913E-011, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[24].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[24].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[24].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[24].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[24].Nominal",\
 "", 6.239860227130913E-011, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[24].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[25].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", \
1.039976704521819E-018, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[25].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[25].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[25].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[25].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[25].Nominal",\
 "", 1.039976704521819E-018, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[25].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[26].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", 1.0, 0.0,0.0,\
0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[26].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[26].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[26].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[26].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[26].Nominal",\
 "", 1.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[26].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[27].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", 1000.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[27].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[27].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[27].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[27].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[27].Nominal",\
 "", 1000.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[27].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[28].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", 10000.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[28].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[28].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[28].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[28].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[28].Nominal",\
 "", 10000.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[28].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[29].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", 1000000.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[29].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[29].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[29].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[29].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[29].Nominal",\
 "", 1000000.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[29].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[30].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", \
0.016666666666666666, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[30].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[30].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[30].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[30].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[30].Nominal",\
 "", 0.016666666666666666, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[30].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[31].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", 0.001, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[31].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[31].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[31].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[31].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[31].Nominal",\
 "", 0.001, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[31].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[32].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", 1.0, 0.0,0.0,\
0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[32].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[32].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[32].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[32].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[32].Nominal",\
 "", 1.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[32].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[33].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", 10.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[33].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[33].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[33].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[33].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[33].Nominal",\
 "", 10.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[33].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[34].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", 1000.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[34].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[34].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[34].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[34].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[34].Nominal",\
 "", 1000.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[34].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[35].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", \
1.6666666666666667E-005, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[35].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[35].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[35].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[35].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[35].Nominal",\
 "", 1.6666666666666667E-005, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[35].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[36].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", 1E-006, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[36].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[36].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[36].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[36].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[36].Nominal",\
 "", 1E-006, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[36].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[37].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", 0.001, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[37].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[37].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[37].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[37].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[37].Nominal",\
 "", 0.001, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[37].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[38].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", 0.01, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[38].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[38].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[38].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[38].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[38].Nominal",\
 "", 0.01, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[38].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[39].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", 1.0, 0.0,0.0,\
0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[39].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[39].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[39].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[39].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[39].Nominal",\
 "", 1.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[39].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[40].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", \
1.6666666666666667E-008, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[40].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[40].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[40].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[40].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[40].Nominal",\
 "", 1.6666666666666667E-008, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[40].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[41].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", 1E-009, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[41].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[41].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[41].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[41].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[41].Nominal",\
 "", 1E-009, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[41].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[42].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", \
1.0000000000000002E-006, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[42].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[42].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[42].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[42].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[42].Nominal",\
 "", 1.0000000000000002E-006, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[42].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[43].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", 1E-005, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[43].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[43].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[43].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[43].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[43].Nominal",\
 "", 1E-005, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[43].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[44].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", 0.001, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[44].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[44].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[44].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[44].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[44].Nominal",\
 "", 0.001, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[44].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[45].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", \
1.6666666666666667E-011, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[45].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[45].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[45].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[45].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[45].Nominal",\
 "", 1.6666666666666667E-011, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[45].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[46].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", 1E-012, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[46].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[46].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[46].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[46].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[46].Nominal",\
 "", 1E-012, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[46].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[47].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", 1E-009, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[47].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[47].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[47].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[47].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[47].Nominal",\
 "", 1E-009, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[47].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[48].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", 1E-008, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[48].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[48].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[48].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[48].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[48].Nominal",\
 "", 1E-008, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[48].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[49].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", 1E-006, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[49].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[49].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[49].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[49].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[49].Nominal",\
 "", 1E-006, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[49].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[50].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", \
1.6666666666666667E-014, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[50].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[50].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[50].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[50].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[50].Nominal",\
 "", 1.6666666666666667E-014, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[50].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[51].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", 1.0, 0.0,0.0,\
0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[51].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[51].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[51].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[51].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[51].Nominal",\
 "", 1.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[51].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[52].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", 1000.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[52].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[52].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[52].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[52].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[52].Nominal",\
 "", 1000.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[52].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[53].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", 10000.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[53].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[53].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[53].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[53].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[53].Nominal",\
 "", 10000.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[53].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[54].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", 1000000.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[54].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[54].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[54].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[54].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[54].Nominal",\
 "", 1000000.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[54].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[55].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", \
0.016666666666666666, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[55].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[55].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[55].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[55].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[55].Nominal",\
 "", 0.016666666666666666, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[55].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[56].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", 0.001, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[56].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[56].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[56].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[56].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[56].Nominal",\
 "", 0.001, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[56].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[57].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", 1.0, 0.0,0.0,\
0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[57].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[57].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[57].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[57].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[57].Nominal",\
 "", 1.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[57].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[58].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", 10.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[58].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[58].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[58].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[58].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[58].Nominal",\
 "", 10.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[58].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[59].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", 1000.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[59].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[59].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[59].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[59].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[59].Nominal",\
 "", 1000.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[59].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[60].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", \
1.6666666666666667E-005, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[60].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[60].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[60].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[60].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[60].Nominal",\
 "", 1.6666666666666667E-005, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[60].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[61].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", 1E-006, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[61].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[61].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[61].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[61].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[61].Nominal",\
 "", 1E-006, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[61].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[62].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", 0.001, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[62].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[62].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[62].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[62].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[62].Nominal",\
 "", 0.001, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[62].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[63].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", 0.01, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[63].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[63].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[63].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[63].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[63].Nominal",\
 "", 0.01, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[63].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[64].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", 1.0, 0.0,0.0,\
0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[64].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[64].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[64].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[64].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[64].Nominal",\
 "", 1.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[64].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[65].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", \
1.6666666666666667E-008, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[65].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[65].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[65].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[65].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[65].Nominal",\
 "", 1.6666666666666667E-008, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[65].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[66].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", 1E-009, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[66].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[66].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[66].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[66].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[66].Nominal",\
 "", 1E-009, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[66].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[67].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", \
1.0000000000000002E-006, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[67].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[67].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[67].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[67].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[67].Nominal",\
 "", 1.0000000000000002E-006, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[67].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[68].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", 1E-005, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[68].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[68].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[68].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[68].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[68].Nominal",\
 "", 1E-005, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[68].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[69].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", 0.001, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[69].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[69].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[69].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[69].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[69].Nominal",\
 "", 0.001, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[69].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[70].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", \
1.6666666666666667E-011, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[70].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[70].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[70].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[70].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[70].Nominal",\
 "", 1.6666666666666667E-011, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[70].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[71].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", 1E-012, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[71].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[71].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[71].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[71].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[71].Nominal",\
 "", 1E-012, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[71].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[72].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", 1E-009, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[72].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[72].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[72].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[72].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[72].Nominal",\
 "", 1E-009, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[72].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[73].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", 1E-008, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[73].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[73].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[73].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[73].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[73].Nominal",\
 "", 1E-008, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[73].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[74].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", 1E-006, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[74].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[74].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[74].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[74].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[74].Nominal",\
 "", 1E-006, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[74].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[75].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", \
1.6666666666666667E-014, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[75].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[75].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[75].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[75].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[75].Nominal",\
 "", 1.6666666666666667E-014, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Leptin.unitConversions[75].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.mw", \
"Molar weight in kg/mol or kDa [kg/mol|kDa]", 5.808, 0.0,1E+100,1.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.dH", \
"Enthalpy [J/mol|kcal/mol]", 0.0, 0.0,0.0,4186.8,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.dS", \
"Entropy [J/mol|kcal/mol]", 0.0, 0.0,0.0,4186.8,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.molpIU", \
"Pharmacological international unit conversion: mols per IU (or 1 if unknown) [mol|mmol]",\
 1.0, 0.0,1E+100,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.molpGU", \
"Goldblatt unit conversion: mols per GU (or 1 if unknown) [mol|mmol]", 1.0, 0.0,\
1E+100,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[1].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", \
0.0001721763085399449, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[1].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[1].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[1].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[1].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[1].Nominal",\
 "", 0.0001721763085399449, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[1].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[2].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", \
0.17217630853994492, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[2].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[2].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[2].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[2].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[2].Nominal",\
 "", 0.17217630853994492, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[2].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[3].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", \
1.721763085399449, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[3].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[3].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[3].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[3].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[3].Nominal",\
 "", 1.721763085399449, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[3].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[4].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", \
172.1763085399449, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[4].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[4].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[4].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[4].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[4].Nominal",\
 "", 172.1763085399449, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[4].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[5].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", \
2.869605142332415E-006, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[5].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[5].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[5].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[5].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[5].Nominal",\
 "", 2.869605142332415E-006, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[5].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[6].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", \
1.721763085399449E-007, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[6].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[6].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[6].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[6].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[6].Nominal",\
 "", 1.721763085399449E-007, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[6].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[7].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", \
0.0001721763085399449, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[7].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[7].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[7].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[7].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[7].Nominal",\
 "", 0.0001721763085399449, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[7].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[8].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", \
0.001721763085399449, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[8].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[8].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[8].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[8].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[8].Nominal",\
 "", 0.001721763085399449, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[8].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[9].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", \
0.17217630853994492, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[9].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[9].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[9].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[9].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[9].Nominal",\
 "", 0.17217630853994492, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[9].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[10].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", \
2.869605142332415E-009, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[10].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[10].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[10].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[10].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[10].Nominal",\
 "", 2.869605142332415E-009, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[10].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[11].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", \
1.721763085399449E-010, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[11].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[11].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[11].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[11].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[11].Nominal",\
 "", 1.721763085399449E-010, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[11].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[12].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", \
1.7217630853994488E-007, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[12].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[12].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[12].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[12].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[12].Nominal",\
 "", 1.7217630853994488E-007, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[12].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[13].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", \
1.7217630853994489E-006, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[13].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[13].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[13].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[13].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[13].Nominal",\
 "", 1.7217630853994489E-006, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[13].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[14].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", \
0.00017217630853994488, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[14].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[14].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[14].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[14].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[14].Nominal",\
 "", 0.00017217630853994488, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[14].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[15].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", \
2.869605142332415E-012, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[15].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[15].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[15].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[15].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[15].Nominal",\
 "", 2.869605142332415E-012, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[15].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[16].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", \
1.721763085399449E-013, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[16].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[16].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[16].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[16].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[16].Nominal",\
 "", 1.721763085399449E-013, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[16].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[17].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", \
1.7217630853994492E-010, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[17].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[17].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[17].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[17].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[17].Nominal",\
 "", 1.7217630853994492E-010, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[17].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[18].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", \
1.721763085399449E-009, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[18].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[18].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[18].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[18].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[18].Nominal",\
 "", 1.721763085399449E-009, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[18].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[19].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", \
1.721763085399449E-007, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[19].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[19].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[19].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[19].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[19].Nominal",\
 "", 1.721763085399449E-007, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[19].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[20].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", \
2.869605142332415E-015, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[20].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[20].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[20].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[20].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[20].Nominal",\
 "", 2.869605142332415E-015, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[20].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[21].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", \
1.721763085399449E-016, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[21].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[21].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[21].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[21].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[21].Nominal",\
 "", 1.721763085399449E-016, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[21].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[22].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", \
1.721763085399449E-013, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[22].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[22].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[22].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[22].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[22].Nominal",\
 "", 1.721763085399449E-013, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[22].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[23].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", \
1.721763085399449E-012, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[23].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[23].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[23].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[23].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[23].Nominal",\
 "", 1.721763085399449E-012, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[23].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[24].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", \
1.721763085399449E-010, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[24].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[24].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[24].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[24].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[24].Nominal",\
 "", 1.721763085399449E-010, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[24].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[25].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", \
2.8696051423324147E-018, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[25].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[25].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[25].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[25].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[25].Nominal",\
 "", 2.8696051423324147E-018, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[25].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[26].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", 1.0, 0.0,0.0,\
0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[26].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[26].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[26].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[26].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[26].Nominal",\
 "", 1.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[26].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[27].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", 1000.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[27].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[27].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[27].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[27].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[27].Nominal",\
 "", 1000.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[27].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[28].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", 10000.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[28].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[28].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[28].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[28].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[28].Nominal",\
 "", 10000.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[28].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[29].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", 1000000.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[29].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[29].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[29].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[29].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[29].Nominal",\
 "", 1000000.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[29].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[30].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", \
0.016666666666666666, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[30].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[30].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[30].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[30].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[30].Nominal",\
 "", 0.016666666666666666, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[30].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[31].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", 0.001, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[31].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[31].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[31].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[31].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[31].Nominal",\
 "", 0.001, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[31].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[32].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", 1.0, 0.0,0.0,\
0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[32].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[32].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[32].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[32].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[32].Nominal",\
 "", 1.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[32].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[33].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", 10.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[33].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[33].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[33].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[33].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[33].Nominal",\
 "", 10.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[33].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[34].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", 1000.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[34].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[34].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[34].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[34].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[34].Nominal",\
 "", 1000.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[34].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[35].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", \
1.6666666666666667E-005, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[35].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[35].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[35].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[35].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[35].Nominal",\
 "", 1.6666666666666667E-005, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[35].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[36].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", 1E-006, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[36].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[36].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[36].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[36].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[36].Nominal",\
 "", 1E-006, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[36].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[37].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", 0.001, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[37].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[37].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[37].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[37].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[37].Nominal",\
 "", 0.001, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[37].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[38].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", 0.01, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[38].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[38].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[38].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[38].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[38].Nominal",\
 "", 0.01, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[38].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[39].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", 1.0, 0.0,0.0,\
0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[39].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[39].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[39].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[39].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[39].Nominal",\
 "", 1.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[39].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[40].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", \
1.6666666666666667E-008, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[40].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[40].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[40].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[40].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[40].Nominal",\
 "", 1.6666666666666667E-008, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[40].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[41].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", 1E-009, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[41].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[41].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[41].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[41].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[41].Nominal",\
 "", 1E-009, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[41].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[42].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", \
1.0000000000000002E-006, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[42].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[42].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[42].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[42].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[42].Nominal",\
 "", 1.0000000000000002E-006, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[42].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[43].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", 1E-005, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[43].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[43].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[43].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[43].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[43].Nominal",\
 "", 1E-005, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[43].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[44].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", 0.001, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[44].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[44].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[44].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[44].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[44].Nominal",\
 "", 0.001, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[44].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[45].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", \
1.6666666666666667E-011, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[45].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[45].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[45].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[45].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[45].Nominal",\
 "", 1.6666666666666667E-011, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[45].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[46].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", 1E-012, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[46].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[46].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[46].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[46].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[46].Nominal",\
 "", 1E-012, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[46].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[47].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", 1E-009, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[47].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[47].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[47].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[47].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[47].Nominal",\
 "", 1E-009, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[47].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[48].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", 1E-008, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[48].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[48].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[48].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[48].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[48].Nominal",\
 "", 1E-008, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[48].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[49].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", 1E-006, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[49].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[49].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[49].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[49].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[49].Nominal",\
 "", 1E-006, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[49].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[50].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", \
1.6666666666666667E-014, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[50].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[50].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[50].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[50].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[50].Nominal",\
 "", 1.6666666666666667E-014, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[50].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[51].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", 1.0, 0.0,0.0,\
0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[51].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[51].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[51].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[51].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[51].Nominal",\
 "", 1.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[51].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[52].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", 1000.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[52].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[52].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[52].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[52].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[52].Nominal",\
 "", 1000.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[52].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[53].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", 10000.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[53].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[53].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[53].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[53].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[53].Nominal",\
 "", 10000.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[53].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[54].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", 1000000.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[54].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[54].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[54].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[54].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[54].Nominal",\
 "", 1000000.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[54].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[55].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", \
0.016666666666666666, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[55].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[55].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[55].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[55].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[55].Nominal",\
 "", 0.016666666666666666, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[55].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[56].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", 0.001, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[56].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[56].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[56].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[56].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[56].Nominal",\
 "", 0.001, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[56].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[57].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", 1.0, 0.0,0.0,\
0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[57].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[57].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[57].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[57].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[57].Nominal",\
 "", 1.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[57].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[58].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", 10.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[58].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[58].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[58].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[58].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[58].Nominal",\
 "", 10.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[58].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[59].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", 1000.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[59].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[59].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[59].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[59].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[59].Nominal",\
 "", 1000.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[59].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[60].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", \
1.6666666666666667E-005, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[60].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[60].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[60].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[60].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[60].Nominal",\
 "", 1.6666666666666667E-005, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[60].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[61].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", 1E-006, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[61].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[61].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[61].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[61].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[61].Nominal",\
 "", 1E-006, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[61].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[62].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", 0.001, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[62].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[62].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[62].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[62].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[62].Nominal",\
 "", 0.001, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[62].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[63].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", 0.01, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[63].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[63].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[63].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[63].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[63].Nominal",\
 "", 0.01, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[63].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[64].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", 1.0, 0.0,0.0,\
0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[64].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[64].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[64].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[64].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[64].Nominal",\
 "", 1.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[64].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[65].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", \
1.6666666666666667E-008, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[65].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[65].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[65].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[65].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[65].Nominal",\
 "", 1.6666666666666667E-008, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[65].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[66].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", 1E-009, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[66].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[66].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[66].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[66].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[66].Nominal",\
 "", 1E-009, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[66].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[67].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", \
1.0000000000000002E-006, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[67].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[67].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[67].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[67].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[67].Nominal",\
 "", 1.0000000000000002E-006, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[67].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[68].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", 1E-005, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[68].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[68].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[68].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[68].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[68].Nominal",\
 "", 1E-005, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[68].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[69].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", 0.001, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[69].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[69].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[69].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[69].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[69].Nominal",\
 "", 0.001, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[69].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[70].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", \
1.6666666666666667E-011, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[70].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[70].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[70].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[70].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[70].Nominal",\
 "", 1.6666666666666667E-011, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[70].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[71].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", 1E-012, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[71].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[71].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[71].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[71].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[71].Nominal",\
 "", 1E-012, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[71].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[72].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", 1E-009, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[72].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[72].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[72].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[72].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[72].Nominal",\
 "", 1E-009, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[72].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[73].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", 1E-008, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[73].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[73].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[73].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[73].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[73].Nominal",\
 "", 1E-008, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[73].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[74].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", 1E-006, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[74].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[74].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[74].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[74].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[74].Nominal",\
 "", 1E-006, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[74].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[75].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", \
1.6666666666666667E-014, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[75].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[75].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[75].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[75].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[75].Nominal",\
 "", 1.6666666666666667E-014, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Insulin.unitConversions[75].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.mw", \
"Molar weight in kg/mol or kDa [kg/mol|kDa]", 0.36044, 0.0,1E+100,1.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.dH", \
"Enthalpy [J/mol|kcal/mol]", 0.0, 0.0,0.0,4186.8,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.dS", \
"Entropy [J/mol|kcal/mol]", 0.0, 0.0,0.0,4186.8,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.molpIU", \
"Pharmacological international unit conversion: mols per IU (or 1 if unknown) [mol|mmol]",\
 1.0, 0.0,1E+100,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.molpGU", \
"Goldblatt unit conversion: mols per GU (or 1 if unknown) [mol|mmol]", 1.0, 0.0,\
1E+100,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[1].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", \
0.002774386860503829, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[1].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[1].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[1].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[1].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[1].Nominal",\
 "", 0.002774386860503829, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[1].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[2].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", \
2.774386860503829, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[2].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[2].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[2].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[2].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[2].Nominal",\
 "", 2.774386860503829, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[2].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[3].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", \
27.74386860503829, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[3].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[3].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[3].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[3].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[3].Nominal",\
 "", 27.74386860503829, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[3].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[4].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", \
2774.386860503829, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[4].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[4].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[4].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[4].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[4].Nominal",\
 "", 2774.386860503829, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[4].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[5].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", \
4.623978100839715E-005, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[5].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[5].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[5].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[5].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[5].Nominal",\
 "", 4.623978100839715E-005, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[5].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[6].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", \
2.774386860503829E-006, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[6].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[6].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[6].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[6].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[6].Nominal",\
 "", 2.774386860503829E-006, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[6].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[7].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", \
0.002774386860503829, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[7].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[7].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[7].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[7].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[7].Nominal",\
 "", 0.002774386860503829, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[7].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[8].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", \
0.02774386860503829, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[8].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[8].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[8].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[8].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[8].Nominal",\
 "", 0.02774386860503829, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[8].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[9].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", \
2.774386860503829, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[9].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[9].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[9].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[9].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[9].Nominal",\
 "", 2.774386860503829, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[9].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[10].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", \
4.623978100839715E-008, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[10].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[10].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[10].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[10].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[10].Nominal",\
 "", 4.623978100839715E-008, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[10].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[11].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", \
2.7743868605038287E-009, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[11].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[11].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[11].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[11].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[11].Nominal",\
 "", 2.7743868605038287E-009, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[11].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[12].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", \
2.7743868605038286E-006, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[12].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[12].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[12].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[12].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[12].Nominal",\
 "", 2.7743868605038286E-006, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[12].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[13].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", \
2.7743868605038287E-005, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[13].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[13].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[13].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[13].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[13].Nominal",\
 "", 2.7743868605038287E-005, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[13].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[14].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", \
0.0027743868605038286, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[14].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[14].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[14].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[14].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[14].Nominal",\
 "", 0.0027743868605038286, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[14].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[15].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", \
4.6239781008397146E-011, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[15].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[15].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[15].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[15].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[15].Nominal",\
 "", 4.6239781008397146E-011, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[15].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[16].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", \
2.774386860503829E-012, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[16].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[16].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[16].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[16].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[16].Nominal",\
 "", 2.774386860503829E-012, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[16].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[17].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", \
2.774386860503829E-009, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[17].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[17].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[17].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[17].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[17].Nominal",\
 "", 2.774386860503829E-009, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[17].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[18].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", \
2.7743868605038292E-008, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[18].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[18].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[18].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[18].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[18].Nominal",\
 "", 2.7743868605038292E-008, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[18].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[19].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", \
2.774386860503829E-006, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[19].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[19].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[19].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[19].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[19].Nominal",\
 "", 2.774386860503829E-006, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[19].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[20].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", \
4.623978100839715E-014, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[20].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[20].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[20].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[20].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[20].Nominal",\
 "", 4.623978100839715E-014, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[20].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[21].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", \
2.7743868605038288E-015, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[21].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[21].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[21].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[21].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[21].Nominal",\
 "", 2.7743868605038288E-015, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[21].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[22].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", \
2.7743868605038287E-012, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[22].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[22].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[22].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[22].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[22].Nominal",\
 "", 2.7743868605038287E-012, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[22].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[23].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", \
2.774386860503829E-011, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[23].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[23].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[23].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[23].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[23].Nominal",\
 "", 2.774386860503829E-011, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[23].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[24].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", \
2.7743868605038287E-009, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[24].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[24].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[24].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[24].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[24].Nominal",\
 "", 2.7743868605038287E-009, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[24].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[25].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", \
4.6239781008397145E-017, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[25].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[25].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[25].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[25].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[25].Nominal",\
 "", 4.6239781008397145E-017, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[25].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[26].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", 1.0, 0.0,0.0,\
0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[26].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[26].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[26].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[26].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[26].Nominal",\
 "", 1.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[26].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[27].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", 1000.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[27].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[27].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[27].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[27].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[27].Nominal",\
 "", 1000.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[27].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[28].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", 10000.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[28].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[28].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[28].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[28].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[28].Nominal",\
 "", 10000.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[28].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[29].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", 1000000.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[29].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[29].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[29].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[29].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[29].Nominal",\
 "", 1000000.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[29].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[30].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", \
0.016666666666666666, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[30].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[30].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[30].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[30].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[30].Nominal",\
 "", 0.016666666666666666, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[30].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[31].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", 0.001, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[31].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[31].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[31].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[31].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[31].Nominal",\
 "", 0.001, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[31].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[32].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", 1.0, 0.0,0.0,\
0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[32].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[32].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[32].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[32].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[32].Nominal",\
 "", 1.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[32].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[33].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", 10.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[33].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[33].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[33].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[33].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[33].Nominal",\
 "", 10.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[33].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[34].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", 1000.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[34].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[34].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[34].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[34].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[34].Nominal",\
 "", 1000.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[34].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[35].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", \
1.6666666666666667E-005, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[35].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[35].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[35].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[35].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[35].Nominal",\
 "", 1.6666666666666667E-005, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[35].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[36].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", 1E-006, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[36].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[36].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[36].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[36].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[36].Nominal",\
 "", 1E-006, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[36].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[37].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", 0.001, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[37].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[37].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[37].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[37].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[37].Nominal",\
 "", 0.001, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[37].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[38].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", 0.01, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[38].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[38].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[38].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[38].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[38].Nominal",\
 "", 0.01, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[38].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[39].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", 1.0, 0.0,0.0,\
0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[39].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[39].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[39].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[39].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[39].Nominal",\
 "", 1.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[39].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[40].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", \
1.6666666666666667E-008, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[40].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[40].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[40].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[40].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[40].Nominal",\
 "", 1.6666666666666667E-008, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[40].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[41].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", 1E-009, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[41].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[41].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[41].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[41].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[41].Nominal",\
 "", 1E-009, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[41].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[42].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", \
1.0000000000000002E-006, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[42].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[42].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[42].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[42].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[42].Nominal",\
 "", 1.0000000000000002E-006, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[42].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[43].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", 1E-005, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[43].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[43].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[43].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[43].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[43].Nominal",\
 "", 1E-005, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[43].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[44].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", 0.001, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[44].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[44].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[44].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[44].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[44].Nominal",\
 "", 0.001, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[44].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[45].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", \
1.6666666666666667E-011, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[45].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[45].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[45].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[45].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[45].Nominal",\
 "", 1.6666666666666667E-011, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[45].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[46].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", 1E-012, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[46].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[46].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[46].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[46].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[46].Nominal",\
 "", 1E-012, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[46].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[47].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", 1E-009, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[47].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[47].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[47].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[47].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[47].Nominal",\
 "", 1E-009, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[47].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[48].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", 1E-008, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[48].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[48].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[48].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[48].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[48].Nominal",\
 "", 1E-008, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[48].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[49].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", 1E-006, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[49].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[49].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[49].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[49].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[49].Nominal",\
 "", 1E-006, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[49].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[50].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", \
1.6666666666666667E-014, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[50].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[50].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[50].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[50].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[50].Nominal",\
 "", 1.6666666666666667E-014, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[50].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[51].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", 1.0, 0.0,0.0,\
0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[51].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[51].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[51].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[51].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[51].Nominal",\
 "", 1.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[51].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[52].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", 1000.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[52].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[52].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[52].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[52].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[52].Nominal",\
 "", 1000.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[52].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[53].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", 10000.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[53].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[53].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[53].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[53].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[53].Nominal",\
 "", 10000.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[53].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[54].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", 1000000.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[54].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[54].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[54].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[54].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[54].Nominal",\
 "", 1000000.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[54].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[55].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", \
0.016666666666666666, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[55].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[55].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[55].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[55].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[55].Nominal",\
 "", 0.016666666666666666, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[55].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[56].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", 0.001, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[56].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[56].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[56].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[56].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[56].Nominal",\
 "", 0.001, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[56].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[57].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", 1.0, 0.0,0.0,\
0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[57].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[57].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[57].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[57].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[57].Nominal",\
 "", 1.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[57].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[58].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", 10.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[58].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[58].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[58].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[58].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[58].Nominal",\
 "", 10.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[58].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[59].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", 1000.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[59].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[59].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[59].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[59].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[59].Nominal",\
 "", 1000.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[59].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[60].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", \
1.6666666666666667E-005, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[60].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[60].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[60].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[60].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[60].Nominal",\
 "", 1.6666666666666667E-005, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[60].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[61].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", 1E-006, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[61].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[61].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[61].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[61].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[61].Nominal",\
 "", 1E-006, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[61].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[62].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", 0.001, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[62].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[62].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[62].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[62].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[62].Nominal",\
 "", 0.001, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[62].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[63].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", 0.01, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[63].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[63].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[63].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[63].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[63].Nominal",\
 "", 0.01, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[63].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[64].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", 1.0, 0.0,0.0,\
0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[64].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[64].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[64].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[64].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[64].Nominal",\
 "", 1.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[64].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[65].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", \
1.6666666666666667E-008, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[65].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[65].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[65].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[65].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[65].Nominal",\
 "", 1.6666666666666667E-008, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[65].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[66].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", 1E-009, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[66].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[66].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[66].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[66].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[66].Nominal",\
 "", 1E-009, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[66].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[67].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", \
1.0000000000000002E-006, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[67].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[67].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[67].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[67].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[67].Nominal",\
 "", 1.0000000000000002E-006, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[67].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[68].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", 1E-005, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[68].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[68].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[68].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[68].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[68].Nominal",\
 "", 1E-005, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[68].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[69].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", 0.001, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[69].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[69].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[69].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[69].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[69].Nominal",\
 "", 0.001, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[69].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[70].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", \
1.6666666666666667E-011, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[70].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[70].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[70].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[70].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[70].Nominal",\
 "", 1.6666666666666667E-011, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[70].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[71].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", 1E-012, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[71].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[71].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[71].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[71].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[71].Nominal",\
 "", 1E-012, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[71].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[72].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", 1E-009, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[72].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[72].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[72].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[72].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[72].Nominal",\
 "", 1E-009, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[72].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[73].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", 1E-008, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[73].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[73].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[73].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[73].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[73].Nominal",\
 "", 1E-008, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[73].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[74].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", 1E-006, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[74].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[74].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[74].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[74].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[74].Nominal",\
 "", 1E-006, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[74].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[75].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", \
1.6666666666666667E-014, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[75].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[75].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[75].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[75].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[75].Nominal",\
 "", 1.6666666666666667E-014, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Aldosterone.unitConversions[75].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.mw", "Molar weight in kg/mol or kDa [kg/mol|kDa]",\
 48.0, 0.0,1E+100,1.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.dH", "Enthalpy [J/mol|kcal/mol]",\
 0.0, 0.0,0.0,4186.8,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.dS", "Entropy [J/mol|kcal/mol]",\
 0.0, 0.0,0.0,4186.8,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.molpIU", \
"Pharmacological international unit conversion: mols per IU (or 1 if unknown) [mol|mmol]",\
 1.0, 0.0,1E+100,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.molpGU", \
"Goldblatt unit conversion: mols per GU (or 1 if unknown) [mol|mmol]", 1.0, 0.0,\
1E+100,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[1].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", \
2.0833333333333333E-005, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[1].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[1].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[1].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[1].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[1].Nominal",\
 "", 2.0833333333333333E-005, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[1].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[2].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", \
0.020833333333333332, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[2].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[2].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[2].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[2].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[2].Nominal",\
 "", 0.020833333333333332, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[2].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[3].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", \
0.20833333333333331, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[3].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[3].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[3].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[3].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[3].Nominal",\
 "", 0.20833333333333331, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[3].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[4].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", \
20.833333333333332, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[4].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[4].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[4].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[4].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[4].Nominal",\
 "", 20.833333333333332, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[4].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[5].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", \
3.472222222222222E-007, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[5].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[5].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[5].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[5].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[5].Nominal",\
 "", 3.472222222222222E-007, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[5].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[6].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", \
2.0833333333333335E-008, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[6].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[6].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[6].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[6].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[6].Nominal",\
 "", 2.0833333333333335E-008, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[6].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[7].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", \
2.0833333333333336E-005, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[7].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[7].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[7].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[7].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[7].Nominal",\
 "", 2.0833333333333336E-005, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[7].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[8].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", \
0.00020833333333333335, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[8].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[8].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[8].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[8].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[8].Nominal",\
 "", 0.00020833333333333335, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[8].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[9].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", \
0.020833333333333336, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[9].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[9].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[9].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[9].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[9].Nominal",\
 "", 0.020833333333333336, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[9].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[10].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", \
3.4722222222222225E-010, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[10].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[10].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[10].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[10].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[10].Nominal",\
 "", 3.4722222222222225E-010, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[10].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[11].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", \
2.0833333333333332E-011, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[11].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[11].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[11].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[11].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[11].Nominal",\
 "", 2.0833333333333332E-011, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[11].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[12].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", \
2.083333333333333E-008, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[12].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[12].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[12].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[12].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[12].Nominal",\
 "", 2.083333333333333E-008, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[12].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[13].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", \
2.0833333333333333E-007, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[13].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[13].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[13].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[13].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[13].Nominal",\
 "", 2.0833333333333333E-007, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[13].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[14].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", \
2.0833333333333333E-005, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[14].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[14].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[14].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[14].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[14].Nominal",\
 "", 2.0833333333333333E-005, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[14].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[15].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", \
3.472222222222222E-013, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[15].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[15].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[15].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[15].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[15].Nominal",\
 "", 3.472222222222222E-013, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[15].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[16].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", \
2.0833333333333334E-014, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[16].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[16].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[16].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[16].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[16].Nominal",\
 "", 2.0833333333333334E-014, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[16].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[17].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", \
2.0833333333333332E-011, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[17].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[17].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[17].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[17].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[17].Nominal",\
 "", 2.0833333333333332E-011, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[17].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[18].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", \
2.0833333333333334E-010, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[18].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[18].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[18].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[18].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[18].Nominal",\
 "", 2.0833333333333334E-010, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[18].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[19].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", \
2.0833333333333335E-008, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[19].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[19].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[19].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[19].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[19].Nominal",\
 "", 2.0833333333333335E-008, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[19].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[20].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", \
3.4722222222222225E-016, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[20].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[20].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[20].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[20].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[20].Nominal",\
 "", 3.4722222222222225E-016, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[20].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[21].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", \
2.0833333333333332E-017, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[21].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[21].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[21].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[21].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[21].Nominal",\
 "", 2.0833333333333332E-017, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[21].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[22].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", \
2.083333333333333E-014, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[22].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[22].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[22].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[22].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[22].Nominal",\
 "", 2.083333333333333E-014, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[22].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[23].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", \
2.0833333333333332E-013, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[23].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[23].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[23].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[23].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[23].Nominal",\
 "", 2.0833333333333332E-013, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[23].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[24].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", \
2.0833333333333332E-011, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[24].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[24].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[24].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[24].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[24].Nominal",\
 "", 2.0833333333333332E-011, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[24].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[25].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", \
3.4722222222222217E-019, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[25].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[25].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[25].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[25].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[25].Nominal",\
 "", 3.4722222222222217E-019, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[25].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[26].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", 1.0, 0.0,0.0,\
0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[26].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[26].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[26].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[26].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[26].Nominal",\
 "", 1.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[26].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[27].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", 1000.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[27].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[27].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[27].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[27].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[27].Nominal",\
 "", 1000.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[27].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[28].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", 10000.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[28].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[28].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[28].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[28].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[28].Nominal",\
 "", 10000.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[28].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[29].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", 1000000.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[29].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[29].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[29].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[29].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[29].Nominal",\
 "", 1000000.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[29].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[30].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", \
0.016666666666666666, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[30].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[30].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[30].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[30].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[30].Nominal",\
 "", 0.016666666666666666, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[30].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[31].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", 0.001, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[31].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[31].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[31].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[31].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[31].Nominal",\
 "", 0.001, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[31].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[32].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", 1.0, 0.0,0.0,\
0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[32].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[32].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[32].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[32].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[32].Nominal",\
 "", 1.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[32].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[33].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", 10.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[33].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[33].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[33].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[33].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[33].Nominal",\
 "", 10.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[33].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[34].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", 1000.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[34].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[34].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[34].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[34].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[34].Nominal",\
 "", 1000.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[34].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[35].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", \
1.6666666666666667E-005, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[35].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[35].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[35].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[35].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[35].Nominal",\
 "", 1.6666666666666667E-005, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[35].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[36].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", 1E-006, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[36].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[36].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[36].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[36].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[36].Nominal",\
 "", 1E-006, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[36].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[37].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", 0.001, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[37].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[37].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[37].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[37].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[37].Nominal",\
 "", 0.001, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[37].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[38].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", 0.01, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[38].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[38].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[38].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[38].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[38].Nominal",\
 "", 0.01, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[38].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[39].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", 1.0, 0.0,0.0,\
0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[39].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[39].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[39].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[39].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[39].Nominal",\
 "", 1.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[39].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[40].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", \
1.6666666666666667E-008, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[40].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[40].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[40].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[40].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[40].Nominal",\
 "", 1.6666666666666667E-008, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[40].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[41].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", 1E-009, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[41].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[41].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[41].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[41].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[41].Nominal",\
 "", 1E-009, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[41].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[42].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", \
1.0000000000000002E-006, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[42].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[42].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[42].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[42].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[42].Nominal",\
 "", 1.0000000000000002E-006, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[42].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[43].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", 1E-005, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[43].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[43].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[43].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[43].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[43].Nominal",\
 "", 1E-005, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[43].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[44].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", 0.001, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[44].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[44].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[44].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[44].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[44].Nominal",\
 "", 0.001, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[44].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[45].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", \
1.6666666666666667E-011, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[45].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[45].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[45].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[45].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[45].Nominal",\
 "", 1.6666666666666667E-011, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[45].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[46].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", 1E-012, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[46].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[46].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[46].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[46].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[46].Nominal",\
 "", 1E-012, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[46].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[47].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", 1E-009, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[47].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[47].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[47].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[47].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[47].Nominal",\
 "", 1E-009, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[47].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[48].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", 1E-008, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[48].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[48].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[48].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[48].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[48].Nominal",\
 "", 1E-008, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[48].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[49].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", 1E-006, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[49].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[49].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[49].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[49].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[49].Nominal",\
 "", 1E-006, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[49].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[50].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", \
1.6666666666666667E-014, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[50].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[50].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[50].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[50].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[50].Nominal",\
 "", 1.6666666666666667E-014, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[50].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[51].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", 1.0, 0.0,0.0,\
0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[51].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[51].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[51].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[51].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[51].Nominal",\
 "", 1.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[51].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[52].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", 1000.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[52].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[52].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[52].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[52].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[52].Nominal",\
 "", 1000.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[52].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[53].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", 10000.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[53].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[53].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[53].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[53].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[53].Nominal",\
 "", 10000.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[53].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[54].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", 1000000.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[54].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[54].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[54].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[54].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[54].Nominal",\
 "", 1000000.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[54].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[55].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", \
0.016666666666666666, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[55].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[55].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[55].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[55].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[55].Nominal",\
 "", 0.016666666666666666, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[55].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[56].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", 0.001, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[56].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[56].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[56].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[56].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[56].Nominal",\
 "", 0.001, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[56].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[57].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", 1.0, 0.0,0.0,\
0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[57].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[57].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[57].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[57].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[57].Nominal",\
 "", 1.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[57].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[58].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", 10.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[58].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[58].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[58].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[58].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[58].Nominal",\
 "", 10.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[58].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[59].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", 1000.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[59].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[59].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[59].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[59].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[59].Nominal",\
 "", 1000.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[59].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[60].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", \
1.6666666666666667E-005, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[60].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[60].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[60].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[60].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[60].Nominal",\
 "", 1.6666666666666667E-005, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[60].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[61].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", 1E-006, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[61].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[61].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[61].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[61].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[61].Nominal",\
 "", 1E-006, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[61].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[62].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", 0.001, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[62].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[62].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[62].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[62].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[62].Nominal",\
 "", 0.001, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[62].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[63].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", 0.01, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[63].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[63].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[63].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[63].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[63].Nominal",\
 "", 0.01, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[63].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[64].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", 1.0, 0.0,0.0,\
0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[64].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[64].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[64].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[64].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[64].Nominal",\
 "", 1.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[64].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[65].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", \
1.6666666666666667E-008, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[65].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[65].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[65].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[65].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[65].Nominal",\
 "", 1.6666666666666667E-008, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[65].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[66].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", 1E-009, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[66].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[66].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[66].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[66].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[66].Nominal",\
 "", 1E-009, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[66].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[67].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", \
1.0000000000000002E-006, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[67].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[67].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[67].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[67].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[67].Nominal",\
 "", 1.0000000000000002E-006, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[67].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[68].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", 1E-005, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[68].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[68].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[68].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[68].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[68].Nominal",\
 "", 1E-005, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[68].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[69].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", 0.001, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[69].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[69].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[69].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[69].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[69].Nominal",\
 "", 0.001, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[69].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[70].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", \
1.6666666666666667E-011, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[70].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[70].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[70].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[70].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[70].Nominal",\
 "", 1.6666666666666667E-011, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[70].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[71].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", 1E-012, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[71].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[71].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[71].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[71].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[71].Nominal",\
 "", 1E-012, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[71].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[72].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", 1E-009, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[72].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[72].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[72].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[72].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[72].Nominal",\
 "", 1E-009, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[72].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[73].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", 1E-008, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[73].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[73].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[73].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[73].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[73].Nominal",\
 "", 1E-008, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[73].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[74].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", 1E-006, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[74].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[74].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[74].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[74].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[74].Nominal",\
 "", 1E-006, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[74].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[75].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", \
1.6666666666666667E-014, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[75].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[75].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[75].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[75].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[75].Nominal",\
 "", 1.6666666666666667E-014, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Renin.unitConversions[75].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.mw", \
"Molar weight in kg/mol or kDa [kg/mol|kDa]", 0.16918, 0.0,1E+100,1.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.dH", \
"Enthalpy [J/mol|kcal/mol]", 0.0, 0.0,0.0,4186.8,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.dS", \
"Entropy [J/mol|kcal/mol]", 0.0, 0.0,0.0,4186.8,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.molpIU", \
"Pharmacological international unit conversion: mols per IU (or 1 if unknown) [mol|mmol]",\
 1.0, 0.0,1E+100,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.molpGU", \
"Goldblatt unit conversion: mols per GU (or 1 if unknown) [mol|mmol]", 1.0, 0.0,\
1E+100,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[1].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", \
0.005910864168341412, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[1].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[1].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[1].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[1].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[1].Nominal",\
 "", 0.005910864168341412, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[1].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[2].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", \
5.910864168341412, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[2].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[2].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[2].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[2].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[2].Nominal",\
 "", 5.910864168341412, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[2].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[3].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", \
59.10864168341412, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[3].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[3].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[3].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[3].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[3].Nominal",\
 "", 59.10864168341412, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[3].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[4].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", \
5910.864168341412, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[4].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[4].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[4].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[4].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[4].Nominal",\
 "", 5910.864168341412, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[4].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[5].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", \
9.85144028056902E-005, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[5].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[5].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[5].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[5].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[5].Nominal",\
 "", 9.85144028056902E-005, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[5].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[6].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", \
5.910864168341412E-006, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[6].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[6].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[6].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[6].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[6].Nominal",\
 "", 5.910864168341412E-006, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[6].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[7].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", \
0.005910864168341412, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[7].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[7].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[7].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[7].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[7].Nominal",\
 "", 0.005910864168341412, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[7].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[8].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", \
0.05910864168341412, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[8].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[8].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[8].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[8].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[8].Nominal",\
 "", 0.05910864168341412, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[8].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[9].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", \
5.910864168341412, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[9].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[9].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[9].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[9].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[9].Nominal",\
 "", 5.910864168341412, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[9].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[10].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", \
9.85144028056902E-008, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[10].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[10].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[10].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[10].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[10].Nominal",\
 "", 9.85144028056902E-008, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[10].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[11].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", \
5.910864168341412E-009, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[11].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[11].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[11].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[11].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[11].Nominal",\
 "", 5.910864168341412E-009, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[11].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[12].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", \
5.910864168341412E-006, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[12].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[12].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[12].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[12].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[12].Nominal",\
 "", 5.910864168341412E-006, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[12].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[13].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", \
5.910864168341412E-005, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[13].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[13].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[13].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[13].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[13].Nominal",\
 "", 5.910864168341412E-005, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[13].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[14].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", \
0.005910864168341412, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[14].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[14].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[14].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[14].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[14].Nominal",\
 "", 0.005910864168341412, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[14].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[15].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", \
9.85144028056902E-011, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[15].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[15].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[15].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[15].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[15].Nominal",\
 "", 9.85144028056902E-011, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[15].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[16].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", \
5.910864168341413E-012, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[16].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[16].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[16].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[16].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[16].Nominal",\
 "", 5.910864168341413E-012, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[16].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[17].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", \
5.910864168341413E-009, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[17].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[17].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[17].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[17].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[17].Nominal",\
 "", 5.910864168341413E-009, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[17].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[18].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", \
5.9108641683414125E-008, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[18].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[18].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[18].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[18].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[18].Nominal",\
 "", 5.9108641683414125E-008, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[18].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[19].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", \
5.910864168341413E-006, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[19].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[19].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[19].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[19].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[19].Nominal",\
 "", 5.910864168341413E-006, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[19].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[20].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", \
9.851440280569022E-014, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[20].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[20].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[20].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[20].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[20].Nominal",\
 "", 9.851440280569022E-014, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[20].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[21].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", \
5.910864168341412E-015, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[21].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[21].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[21].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[21].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[21].Nominal",\
 "", 5.910864168341412E-015, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[21].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[22].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", \
5.910864168341412E-012, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[22].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[22].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[22].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[22].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[22].Nominal",\
 "", 5.910864168341412E-012, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[22].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[23].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", \
5.910864168341412E-011, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[23].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[23].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[23].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[23].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[23].Nominal",\
 "", 5.910864168341412E-011, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[23].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[24].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", \
5.910864168341412E-009, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[24].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[24].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[24].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[24].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[24].Nominal",\
 "", 5.910864168341412E-009, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[24].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[25].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", \
9.85144028056902E-017, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[25].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[25].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[25].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[25].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[25].Nominal",\
 "", 9.85144028056902E-017, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[25].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[26].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", 1.0, 0.0,0.0,\
0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[26].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[26].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[26].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[26].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[26].Nominal",\
 "", 1.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[26].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[27].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", 1000.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[27].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[27].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[27].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[27].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[27].Nominal",\
 "", 1000.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[27].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[28].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", 10000.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[28].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[28].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[28].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[28].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[28].Nominal",\
 "", 10000.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[28].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[29].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", 1000000.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[29].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[29].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[29].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[29].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[29].Nominal",\
 "", 1000000.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[29].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[30].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", \
0.016666666666666666, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[30].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[30].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[30].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[30].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[30].Nominal",\
 "", 0.016666666666666666, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[30].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[31].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", 0.001, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[31].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[31].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[31].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[31].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[31].Nominal",\
 "", 0.001, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[31].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[32].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", 1.0, 0.0,0.0,\
0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[32].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[32].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[32].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[32].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[32].Nominal",\
 "", 1.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[32].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[33].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", 10.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[33].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[33].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[33].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[33].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[33].Nominal",\
 "", 10.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[33].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[34].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", 1000.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[34].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[34].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[34].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[34].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[34].Nominal",\
 "", 1000.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[34].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[35].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", \
1.6666666666666667E-005, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[35].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[35].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[35].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[35].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[35].Nominal",\
 "", 1.6666666666666667E-005, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[35].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[36].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", 1E-006, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[36].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[36].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[36].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[36].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[36].Nominal",\
 "", 1E-006, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[36].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[37].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", 0.001, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[37].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[37].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[37].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[37].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[37].Nominal",\
 "", 0.001, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[37].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[38].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", 0.01, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[38].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[38].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[38].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[38].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[38].Nominal",\
 "", 0.01, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[38].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[39].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", 1.0, 0.0,0.0,\
0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[39].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[39].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[39].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[39].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[39].Nominal",\
 "", 1.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[39].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[40].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", \
1.6666666666666667E-008, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[40].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[40].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[40].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[40].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[40].Nominal",\
 "", 1.6666666666666667E-008, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[40].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[41].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", 1E-009, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[41].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[41].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[41].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[41].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[41].Nominal",\
 "", 1E-009, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[41].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[42].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", \
1.0000000000000002E-006, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[42].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[42].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[42].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[42].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[42].Nominal",\
 "", 1.0000000000000002E-006, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[42].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[43].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", 1E-005, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[43].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[43].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[43].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[43].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[43].Nominal",\
 "", 1E-005, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[43].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[44].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", 0.001, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[44].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[44].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[44].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[44].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[44].Nominal",\
 "", 0.001, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[44].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[45].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", \
1.6666666666666667E-011, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[45].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[45].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[45].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[45].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[45].Nominal",\
 "", 1.6666666666666667E-011, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[45].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[46].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", 1E-012, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[46].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[46].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[46].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[46].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[46].Nominal",\
 "", 1E-012, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[46].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[47].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", 1E-009, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[47].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[47].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[47].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[47].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[47].Nominal",\
 "", 1E-009, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[47].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[48].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", 1E-008, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[48].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[48].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[48].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[48].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[48].Nominal",\
 "", 1E-008, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[48].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[49].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", 1E-006, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[49].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[49].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[49].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[49].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[49].Nominal",\
 "", 1E-006, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[49].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[50].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", \
1.6666666666666667E-014, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[50].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[50].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[50].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[50].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[50].Nominal",\
 "", 1.6666666666666667E-014, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[50].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[51].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", 1.0, 0.0,0.0,\
0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[51].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[51].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[51].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[51].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[51].Nominal",\
 "", 1.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[51].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[52].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", 1000.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[52].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[52].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[52].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[52].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[52].Nominal",\
 "", 1000.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[52].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[53].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", 10000.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[53].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[53].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[53].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[53].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[53].Nominal",\
 "", 10000.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[53].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[54].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", 1000000.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[54].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[54].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[54].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[54].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[54].Nominal",\
 "", 1000000.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[54].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[55].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", \
0.016666666666666666, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[55].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[55].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[55].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[55].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[55].Nominal",\
 "", 0.016666666666666666, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[55].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[56].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", 0.001, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[56].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[56].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[56].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[56].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[56].Nominal",\
 "", 0.001, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[56].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[57].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", 1.0, 0.0,0.0,\
0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[57].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[57].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[57].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[57].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[57].Nominal",\
 "", 1.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[57].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[58].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", 10.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[58].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[58].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[58].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[58].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[58].Nominal",\
 "", 10.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[58].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[59].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", 1000.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[59].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[59].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[59].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[59].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[59].Nominal",\
 "", 1000.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[59].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[60].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", \
1.6666666666666667E-005, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[60].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[60].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[60].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[60].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[60].Nominal",\
 "", 1.6666666666666667E-005, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[60].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[61].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", 1E-006, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[61].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[61].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[61].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[61].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[61].Nominal",\
 "", 1E-006, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[61].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[62].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", 0.001, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[62].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[62].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[62].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[62].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[62].Nominal",\
 "", 0.001, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[62].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[63].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", 0.01, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[63].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[63].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[63].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[63].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[63].Nominal",\
 "", 0.01, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[63].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[64].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", 1.0, 0.0,0.0,\
0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[64].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[64].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[64].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[64].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[64].Nominal",\
 "", 1.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[64].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[65].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", \
1.6666666666666667E-008, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[65].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[65].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[65].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[65].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[65].Nominal",\
 "", 1.6666666666666667E-008, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[65].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[66].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", 1E-009, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[66].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[66].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[66].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[66].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[66].Nominal",\
 "", 1E-009, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[66].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[67].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", \
1.0000000000000002E-006, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[67].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[67].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[67].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[67].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[67].Nominal",\
 "", 1.0000000000000002E-006, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[67].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[68].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", 1E-005, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[68].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[68].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[68].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[68].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[68].Nominal",\
 "", 1E-005, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[68].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[69].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", 0.001, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[69].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[69].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[69].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[69].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[69].Nominal",\
 "", 0.001, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[69].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[70].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", \
1.6666666666666667E-011, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[70].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[70].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[70].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[70].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[70].Nominal",\
 "", 1.6666666666666667E-011, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[70].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[71].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", 1E-012, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[71].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[71].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[71].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[71].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[71].Nominal",\
 "", 1E-012, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[71].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[72].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", 1E-009, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[72].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[72].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[72].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[72].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[72].Nominal",\
 "", 1E-009, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[72].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[73].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", 1E-008, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[73].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[73].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[73].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[73].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[73].Nominal",\
 "", 1E-008, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[73].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[74].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", 1E-006, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[74].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[74].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[74].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[74].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[74].Nominal",\
 "", 1E-006, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[74].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[75].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", \
1.6666666666666667E-014, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[75].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[75].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[75].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[75].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[75].Nominal",\
 "", 1.6666666666666667E-014, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiomodel.Substances.Norepinephrine.unitConversions[75].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[1].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", 1.0, 0.0,0.0,\
0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[1].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[1].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[1].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[1].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[1].Nominal",\
 "", 1.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[1].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[2].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", 1.0, 0.0,0.0,\
0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[2].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[2].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[2].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[2].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[2].Nominal",\
 "", 1.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[2].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[3].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", 1.0, 0.0,0.0,\
0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[3].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[3].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[3].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[3].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[3].Nominal",\
 "", 1.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[3].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[4].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", 4186.8, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[4].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[4].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[4].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[4].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[4].Nominal",\
 "", 4186.8, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[4].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[5].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", 60.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[5].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[5].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[5].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[5].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[5].Nominal",\
 "", 60.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[5].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[6].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", 1.0, 0.0,0.0,\
0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[6].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[6].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[6].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[6].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[6].Nominal",\
 "", 1.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[6].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[7].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", \
0.016666666666666666, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[7].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[7].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[7].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[7].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[7].Nominal",\
 "", 0.016666666666666666, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[7].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[8].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", 0.001, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[8].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[8].Min",\
 "minimal value", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[8].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[8].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[8].Nominal",\
 "", 0.001, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[8].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[9].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", 1E-006, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[9].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[9].Min",\
 "minimal value", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[9].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[9].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[9].Nominal",\
 "", 1E-006, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[9].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[10].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", \
1.6666666666666667E-008, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[10].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[10].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[10].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[10].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[10].Nominal",\
 "", 1.6666666666666667E-008, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[10].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[11].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", \
1.6666666666666667E-005, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[11].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[11].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[11].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[11].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[11].Nominal",\
 "", 1.6666666666666667E-005, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[11].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[12].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", 1000.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[12].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[12].Min",\
 "minimal value", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[12].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[12].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[12].Nominal",\
 "", 1000.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[12].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[13].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", 1.0, 0.0,0.0,\
0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[13].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[13].Min",\
 "minimal value", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[13].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[13].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[13].Nominal",\
 "", 1.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[13].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[14].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", 0.001, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[14].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[14].Min",\
 "minimal value", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[14].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[14].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[14].Nominal",\
 "", 0.001, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[14].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[15].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", \
0.009999999999999999, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[15].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[15].Min",\
 "minimal value", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[15].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[15].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[15].Nominal",\
 "", 0.009999999999999999, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[15].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[16].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", 1E-009, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[16].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[16].Min",\
 "minimal value", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[16].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[16].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[16].Nominal",\
 "", 1E-009, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[16].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[17].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", \
9.999999999999999E-009, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[17].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[17].Min",\
 "minimal value", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[17].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[17].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[17].Nominal",\
 "", 9.999999999999999E-009, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[17].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[18].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", 1E-006, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[18].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[18].Min",\
 "minimal value", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[18].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[18].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[18].Nominal",\
 "", 1E-006, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[18].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[19].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", 0.01, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[19].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[19].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[19].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[19].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[19].Nominal",\
 "", 0.01, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[19].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[20].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", 0.44704, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[20].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[20].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[20].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[20].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[20].Nominal",\
 "", 0.44704, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[20].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[21].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", 1.0, 0.0,0.0,\
0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[21].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[21].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[21].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[21].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[21].Nominal",\
 "", 1.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[21].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[22].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", \
133.32236842105263, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[22].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[22].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[22].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[22].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[22].Nominal",\
 "", 133.32236842105263, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[22].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[23].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", 1E-006, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[23].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[23].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[23].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[23].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[23].Nominal",\
 "", 1E-006, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[23].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[24].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", \
1.6666666666666667E-008, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[24].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[24].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[24].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[24].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[24].Nominal",\
 "", 1.6666666666666667E-008, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[24].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[25].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", 1000.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[25].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[25].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[25].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[25].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[25].Nominal",\
 "", 1000.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[25].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[26].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", 1.0, 0.0,0.0,\
0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[26].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[26].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[26].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[26].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[26].Nominal",\
 "", 1.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[26].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[27].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", 1E-009, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[27].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[27].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[27].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[27].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[27].Nominal",\
 "", 1E-009, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[27].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[28].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", 6.622E-009, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[28].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[28].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[28].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[28].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[28].Nominal",\
 "", 6.622E-009, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[28].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[29].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", 4.5E-010, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[29].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[29].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[29].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[29].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[29].Nominal",\
 "", 4.5E-010, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[29].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[30].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", 0.001, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[30].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[30].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[30].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[30].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[30].Nominal",\
 "", 0.001, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[30].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[31].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", 1.0, 0.0,0.0,\
0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[31].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[31].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[31].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[31].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[31].Nominal",\
 "", 1.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[31].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[32].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", 0.001, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[32].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[32].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[32].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[32].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[32].Nominal",\
 "", 0.001, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[32].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[33].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", \
1.6666666666666667E-005, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[33].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[33].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[33].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[33].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[33].Nominal",\
 "", 1.6666666666666667E-005, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[33].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[34].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", \
7.338602876199938E-007, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[34].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[34].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[34].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[34].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[34].Nominal",\
 "", 7.338602876199938E-007, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[34].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[35].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", 4186.8, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[35].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[35].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[35].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[35].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[35].Nominal",\
 "", 4186.8, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[35].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[36].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", 1.0, 0.0,0.0,\
0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[36].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[36].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[36].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[36].Start",\
 "", 310.15, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[36].Nominal",\
 "", 1.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[36].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[37].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", 1.0, 0.0,0.0,\
0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[37].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 273.15, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[37].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[37].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[37].Start",\
 "", 310.15, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[37].Nominal",\
 "", 1.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[37].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[38].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", 1.0, 0.0,0.0,\
0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[38].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[38].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[38].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[38].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[38].Nominal",\
 "", 1.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[38].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[39].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", 69.78, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[39].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[39].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[39].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[39].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[39].Nominal",\
 "", 69.78, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[39].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[40].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", 0.06978, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[40].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[40].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[40].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[40].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[40].Nominal",\
 "", 0.06978, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[40].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[41].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", 69.78, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[41].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[41].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[41].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[41].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[41].Nominal",\
 "", 69.78, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[41].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[42].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", 4186.8, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[42].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[42].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[42].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[42].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[42].Nominal",\
 "", 4186.8, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[42].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[43].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", 4186.8, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[43].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[43].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[43].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[43].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[43].Nominal",\
 "", 4186.8, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[43].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[44].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", 0.001, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[44].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[44].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[44].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[44].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[44].Nominal",\
 "", 0.001, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[44].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[45].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", \
96.48533990000001, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[45].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[45].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[45].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[45].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[45].Nominal",\
 "", 96.48533990000001, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[45].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[46].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", 96485.3399, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[46].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[46].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[46].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[46].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[46].Nominal",\
 "", 96485.3399, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[46].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[47].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", 96485339.9, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[47].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[47].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[47].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[47].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[47].Nominal",\
 "", 96485339.9, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[47].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[48].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", \
1.6080889983333335, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[48].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[48].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[48].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[48].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[48].Nominal",\
 "", 1.6080889983333335, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[48].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[49].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", 0.01, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[49].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[49].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[49].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[49].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[49].Nominal",\
 "", 0.01, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[49].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[50].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", \
1.6666666666666667E-005, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[50].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[50].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[50].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[50].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[50].Nominal",\
 "", 1.6666666666666667E-005, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[50].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[51].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", \
1.6666666666666667E-005, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[51].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[51].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[51].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[51].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[51].Nominal",\
 "", 1.6666666666666667E-005, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[51].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[52].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", \
1.2501028045069496E-010, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[52].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[52].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[52].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[52].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[52].Nominal",\
 "", 1.2501028045069496E-010, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[52].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[53].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", \
7.500616827041698E-009, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[53].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[53].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[53].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[53].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[53].Nominal",\
 "", 7.500616827041698E-009, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[53].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[54].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", \
479960526315.7895, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[54].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[54].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[54].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[54].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[54].Nominal",\
 "", 479960526315.7895, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[54].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[55].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", \
0.007500616827041697, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[55].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[55].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[55].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[55].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[55].Nominal",\
 "", 0.007500616827041697, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[55].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[56].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", 1.0, 0.0,0.0,\
0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[56].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[56].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[56].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[56].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[56].Nominal",\
 "", 1.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[56].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[57].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", 1000.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[57].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[57].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[57].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[57].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[57].Nominal",\
 "", 1000.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[57].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[58].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", 4186.8, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[58].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[58].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[58].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[58].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[58].Nominal",\
 "", 4186.8, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[58].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[59].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", 1000.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[59].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[59].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[59].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[59].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[59].Nominal",\
 "", 1000.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[59].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[60].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", 1.0, 0.0,0.0,\
0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[60].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[60].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[60].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[60].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[60].Nominal",\
 "", 1.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[60].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[61].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", \
0.016666666666666666, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[61].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[61].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[61].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[61].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[61].Nominal",\
 "", 0.016666666666666666, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[61].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[62].Scale",\
 "Scale from display unit to SI unit such that x <d> = x*s+o <u>", \
1.1574074074074073E-005, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[62].Offset",\
 "Offset from display unit to SI unit such that x <d> = x*s+o <u>", 0.0, \
0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[62].Min",\
 "minimal value", -1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[62].Max",\
 "", 1E+060, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[62].Start",\
 "", 0.0, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[62].Nominal",\
 "", 1.1574074074074073E-005, 0.0,0.0,0.0,0,2561)
DeclareVariable("_GlobalScope.Physiolibrary.Types.Utilities.UnitConversions.RealTypeDef[62].StateSelection",\
 "[:#(type=StateSelect)]", 3, 1.0,5.0,0.0,0,2565)
EndNonAlias(15)
PreNonAliasNew(16)
