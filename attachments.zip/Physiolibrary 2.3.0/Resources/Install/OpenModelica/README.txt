Download and install - https://openmodelica.org/

Physiolibrary should be already included - menu: "File > System Libraries".
