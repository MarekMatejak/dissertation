To add library and display units to current version of Dymola (version connected with .mo file) please run "install.bat".

To unistall please run generated "uninstall.bat".

