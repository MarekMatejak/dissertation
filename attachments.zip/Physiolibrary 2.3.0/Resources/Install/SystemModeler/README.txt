Be carefull, this installation is not tested! It should copy the Physiolibrary files into ProgramFiles/Wolfram/SystemModeler directory.

To add library WITHOUT display units to Wolfram SystemModeler 4.0 please run "install.bat".

Current support of SystemModeler is limited:
 - Steady state examples are not running. 
 - Without display units.


